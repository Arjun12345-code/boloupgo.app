<?php
/**
 * Hello Elementor Child Theme Functions
 * Enqueues sitewide style.css
 */

add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style(
        'boloup-go-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array(),
        '1.0.0'
    );
}, 20);

// Disable WordPress default admin bar on front-end for clean view
add_filter('show_admin_bar', '__return_false');

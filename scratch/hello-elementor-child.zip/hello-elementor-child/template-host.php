<?php
/**
 * Template Name: BoloUp Go Host Page
 * Template Post Type: page
 */
get_header();
?>
<!-- ==========================================================================
     BoloUp Go Official - Header Component (header.html)
     For WordPress Elementor Theme Builder Header Template
     ========================================================================== -->
<header class="header" id="header">
  <div class="header-container">
    <a href="/" class="brand-logo" id="brand-logo" aria-label="BoloUp Go Official Home">
      <img src="https://boloupgo.app/wp-content/uploads/2026/11/logo-samping.png" alt="BoloUp Go Official Logo"
        class="brand-logo-icon" width="914" height="261">
    </a>

    <nav class="nav-menu" id="nav-menu" aria-label="Main Navigation">
      <a href="/" class="nav-link" id="nav-home">Home</a>
      <a href="/host" class="nav-link" id="nav-host">Host</a>
      <a href="/agent" class="nav-link" id="nav-agent">Agent</a>
      <a href="/contact" class="nav-link" id="nav-contact">Contact</a>
      <div class="mobile-nav-actions">
        <a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer" class="btn btn-outline" id="btn-mobile-download">Download App</a>
        <a href="/host" class="btn btn-primary" id="btn-mobile-host">Become a Host</a>
      </div>
    </nav>

    <div class="header-actions">
      <a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer" class="btn btn-outline btn-sm" id="btn-header-download">Download App</a>
      <a href="/host" class="btn btn-primary btn-sm" id="btn-header-host">Become a Host</a>
      <button type="button" class="menu-toggle" id="menu-toggle" aria-label="Toggle Navigation Menu" aria-expanded="false" aria-controls="nav-menu">&#9776;</button>
    </div>
  </div>
</header>

<script>
  (function () {
    // Set background to deep dark
    document.documentElement.style.setProperty('background-color', '#080718', 'important');
    if (document.body) {
      document.body.style.setProperty('background-color', '#080718', 'important');
    }

    const menuToggle = document.getElementById('menu-toggle');
    const navMenu = document.getElementById('nav-menu');
    if (menuToggle && navMenu) {
      function toggleMenu(open) {
        const shouldOpen = open !== undefined ? open : !navMenu.classList.contains('active');
        navMenu.classList.toggle('active', shouldOpen);
        menuToggle.textContent = shouldOpen ? '✕' : '☰';
        menuToggle.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
      }

      menuToggle.addEventListener('click', function (e) {
        e.stopPropagation();
        toggleMenu();
      });

      // Close menu when clicking outside
      document.addEventListener('click', function (e) {
        if (!navMenu.contains(e.target) && !menuToggle.contains(e.target)) {
          toggleMenu(false);
        }
      });

      // Close menu when a link inside is clicked
      navMenu.querySelectorAll('a').forEach(function (link) {
        link.addEventListener('click', function () {
          toggleMenu(false);
        });
      });

      // Close on Escape key
      document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && navMenu.classList.contains('active')) {
          toggleMenu(false);
        }
      });
    }

    // Highlight current page active link
    const currentPath = window.location.pathname.replace(/\/+$/, '') || '/';
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(function (link) {
      const href = (link.getAttribute('href') || '').replace(/\/+$/, '') || '/';
      if (href === currentPath || (href === '/' && (currentPath === '' || currentPath === '/index.html'))) {
        link.classList.add('active');
      }
    });

    // Fixed Header Lock & Elementor parent container cleanup
    const header = document.getElementById('header');
    if (header) {
      function lockHeaderPosition() {
        header.style.setProperty('position', 'fixed', 'important');
        header.style.setProperty('top', '0px', 'important');
        header.style.setProperty('left', '0px', 'important');
        header.style.setProperty('right', '0px', 'important');
        header.style.setProperty('width', '100%', 'important');
        header.style.setProperty('z-index', '99999', 'important');

        // Check if WordPress admin bar is present and offset top
        const wpAdminBar = document.getElementById('wpadminbar');
        if (wpAdminBar) {
          const barHeight = wpAdminBar.offsetHeight || 32;
          header.style.setProperty('top', barHeight + 'px', 'important');
        }
      }

      window.addEventListener('scroll', lockHeaderPosition, { passive: true });
      window.addEventListener('resize', lockHeaderPosition);
      document.addEventListener('DOMContentLoaded', lockHeaderPosition);
      lockHeaderPosition();
    }
  })();
</script>

<main>
<!-- Hero Section -->
  <section class="hero-section hero-host" id="hero">
    <div class="container">
      <div class="hero-grid">
        <div class="hero-content">
          <div class="badge-partner">
            <span class="badge-dot"></span>
            BoloUp Go Creator Space
          </div>
          <h1 class="hero-title">
            <span class="text-gradient">Make Every Live Moment Count as a BoloUp Go Host</span>
          </h1>
          <p class="hero-desc">
            Bring your personality on screen, start conversations, and turn viewers into a community. As a BoloUp Go Host, you can create live experiences, receive gifts, and earn through every interaction.
          </p>
          <div class="hero-actions">
            <a href="#registration" class="btn btn-primary btn-lg" id="hero-cta-host">
              Become a BoloUp Go Host
            </a>
            <a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer"
              class="btn btn-outline btn-lg" id="hero-cta-download">
              Download App
            </a>
          </div>
        </div>

        <div class="hero-visual" id="hero-visual-host">
          <div class="hero-visual-frame">
            <img src="https://boloupgo.app/wp-content/uploads/2026/11/boloup-host-cutout.png"
              alt="Make Every Live Moment Count as a BoloUp Go Host" class="hero-img" width="1553" height="1457"
              fetchpriority="high">
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- BoloUp Go Host Benefits Section -->
  <section class="section section-dark" id="benefits">
    <div class="container">
      <div class="section-title-wrap">
        <h2 class="section-title">More Than Going Live, Build Something of Your Own</h2>
      </div>

      <div class="benefits-grid">
        <div class="benefit-card" id="benefit-live-space">
          <div class="feature-icon-box">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24" aria-hidden="true">
              <path d="m22 8-6 4 6 4V8Z" />
              <rect width="14" height="12" x="2" y="6" rx="2" />
            </svg>
          </div>
          <h3 class="benefit-title">1. Create Your Own Live Space</h3>
          <p class="benefit-desc">
            Make every stream feel like yours. Talk, entertain, share your interests, and give viewers a reason to come back.
          </p>
        </div>

        <div class="benefit-card" id="benefit-viewer-rewards">
          <div class="feature-icon-box pink">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24" aria-hidden="true">
              <rect x="3" y="8" width="18" height="4" rx="1" />
              <path d="M12 8v13" />
              <path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7" />
              <path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5" />
            </svg>
          </div>
          <h3 class="benefit-title">2. Turn Viewer Support into Rewards</h3>
          <p class="benefit-desc">
            Viewers can show their appreciation through virtual gifts while you focus on creating engaging live experiences.
          </p>
        </div>

        <div class="benefit-card" id="benefit-agency-support">
          <div class="feature-icon-box accent">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24" aria-hidden="true">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
            </svg>
          </div>
          <h3 class="benefit-title">3. Grow &amp; Earn with Agency Support</h3>
          <p class="benefit-desc">
            Joining an agency connects you with additional guidance as you learn the platform, develop your style, and build your audience and income.
          </p>
        </div>
      </div>
    </div>
  </section>

  <!-- Registration Tutorial Section -->
  <section class="section section-deep" id="registration">
    <div class="container">
      <div class="section-title-wrap">
        <h2 class="section-title">How to Become a BoloUp Go Host</h2>
      </div>

      <div class="steps-alternate" id="host-registration-steps">
        <!-- Step 1 -->
        <div class="step-alt-row" id="host-reg-step-1">
          <div class="step-alt-visual" onclick="openLightbox(this)" data-src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Host-Registration-Guide-Step-1.jpg" data-alt="How to Become a BoloUp Go Host - Step 1">
            <div class="step-alt-frame">
              <img src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Host-Registration-Guide-Step-1.jpg"
                alt="How to Become a BoloUp Go Host - Step 1" width="757" height="757" loading="lazy" class="step-alt-img">
              <div class="step-zoom-badge" aria-label="Zoom image">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>
              </div>
            </div>
          </div>
          <div class="step-alt-content">
            <div class="step-number">1</div>
            <h3 class="step-title">Step 1 – Download BoloUp Go</h3>
            <p class="step-desc">
              Install the app and create your account using one of the available sign-up options.
            </p>
          </div>
        </div>

        <!-- Step 2 -->
        <div class="step-alt-row step-alt-reverse" id="host-reg-step-2">
          <div class="step-alt-visual" onclick="openLightbox(this)" data-src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Host-Registration-Guide-Step-2.jpg" data-alt="How to Become a BoloUp Go Host - Step 2">
            <div class="step-alt-frame">
              <img src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Host-Registration-Guide-Step-2.jpg"
                alt="How to Become a BoloUp Go Host - Step 2" width="830" height="830" loading="lazy" class="step-alt-img">
              <div class="step-zoom-badge" aria-label="Zoom image">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>
              </div>
            </div>
          </div>
          <div class="step-alt-content">
            <div class="step-number accent">2</div>
            <h3 class="step-title">Step 2 – Find Become Host</h3>
            <p class="step-desc">
              Open your profile, locate Become Host, and tap Join to begin.
            </p>
          </div>
        </div>

        <!-- Step 3 -->
        <div class="step-alt-row" id="host-reg-step-3">
          <div class="step-alt-visual" onclick="openLightbox(this)" data-src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Host-Registration-Guide-Step-3.jpg" data-alt="How to Become a BoloUp Go Host - Step 3">
            <div class="step-alt-frame">
              <img src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Host-Registration-Guide-Step-3.jpg"
                alt="How to Become a BoloUp Go Host - Step 3" width="1054" height="790" loading="lazy" class="step-alt-img">
              <div class="step-zoom-badge" aria-label="Zoom image">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>
              </div>
            </div>
          </div>
          <div class="step-alt-content">
            <div class="step-number">3</div>
            <h3 class="step-title">Step 3 – Join an Agency</h3>
            <p class="step-desc">
              Open the Join Agency form and enter the Agency ID (2527626) provided by your chosen agency.
            </p>
          </div>
        </div>

        <!-- Step 4 -->
        <div class="step-alt-row step-alt-reverse" id="host-reg-step-4">
          <div class="step-alt-visual" onclick="openLightbox(this)" data-src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Host-Registration-Guide-Step-4.jpg" data-alt="How to Become a BoloUp Go Host - Step 4">
            <div class="step-alt-frame">
              <img src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Host-Registration-Guide-Step-4.jpg"
                alt="How to Become a BoloUp Go Host - Step 4" width="828" height="828" loading="lazy" class="step-alt-img">
              <div class="step-zoom-badge" aria-label="Zoom image">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>
              </div>
            </div>
          </div>
          <div class="step-alt-content">
            <div class="step-number accent">4</div>
            <h3 class="step-title">Step 4 – Check the Agency Details</h3>
            <p class="step-desc">
              Review the agency information shown after submitting the ID to make sure you are joining the right team.
            </p>
          </div>
        </div>

        <!-- Step 5 -->
        <div class="step-alt-row" id="host-reg-step-5">
          <div class="step-alt-content" style="max-width: 100%;">
            <div class="step-number">5</div>
            <h3 class="step-title">Step 5 – Complete Face Verification</h3>
            <p class="step-desc">
              Open the Authentication Center from your profile and follow the instructions shown on screen.
            </p>
          </div>
        </div>

        <!-- Step 6 -->
        <div class="step-alt-row" id="host-reg-step-6">
          <div class="step-alt-content" style="max-width: 100%;">
            <div class="step-number accent">6</div>
            <h3 class="step-title">Step 6 – Wait for Approval</h3>
            <p class="step-desc">
              Once your application and verification are approved, your account can officially begin its journey as a BoloUp Go Host.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Withdraw Tutorial Section -->
  <section class="section section-dark" id="withdraw">
    <div class="container">
      <div class="section-title-wrap">
        <h2 class="section-title">How to Withdraw Your BoloUp Go Host Earnings</h2>
      </div>

      <div class="steps-grid">
        <div class="step-card" id="host-withdraw-step-1">
          <div class="step-number">1</div>
          <h3 class="step-title">Step 1 – Open Your Profile</h3>
          <p class="step-desc">
            Log in to BoloUp Go and head to your profile page.
          </p>
        </div>

        <div class="step-card" id="host-withdraw-step-2">
          <div class="step-number accent">2</div>
          <h3 class="step-title">Step 2 – Tap Diamonds</h3>
          <p class="step-desc">
            Open Diamonds to see your eligible balance and payout settings.
          </p>
        </div>

        <div class="step-card" id="host-withdraw-step-3">
          <div class="step-number">3</div>
          <h3 class="step-title">Step 3 – Choose Withdraw Method</h3>
          <p class="step-desc">
            Select Withdraw Method and review the payout options currently available in your region.
          </p>
        </div>

        <div class="step-card" id="host-withdraw-step-4">
          <div class="step-number accent">4</div>
          <h3 class="step-title">Step 4 – Connect Your Payout Account</h3>
          <p class="step-desc">
            Open Withdrawal Info and enter the required bank, e-wallet, Payoneer, USDT, or other supported payout details shown in your account.
          </p>
        </div>

        <div class="step-card" id="host-withdraw-step-5">
          <div class="step-number">5</div>
          <h3 class="step-title">Step 5 – Enter Your Withdrawal Amount</h3>
          <p class="step-desc">
            Choose how much you want to withdraw. Your balance needs to meet the current minimum withdrawal requirement.
          </p>
        </div>

        <div class="step-card" id="host-withdraw-step-6">
          <div class="step-number accent">6</div>
          <h3 class="step-title">Step 6 – Review and Withdraw</h3>
          <p class="step-desc">
            Double-check your payout information and amount, then submit your withdrawal request.
          </p>
        </div>
      </div>

      <!-- Withdraw Infographic Banner -->
      <div class="withdraw-infographic-wrap">
        <div class="withdraw-infographic-card" onclick="openLightbox(this)" data-src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-AgentHost-Withdraw.jpg" data-alt="How to Withdraw Your BoloUp Go Host Earnings">
          <img src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-AgentHost-Withdraw.jpg"
            alt="How to Withdraw Your BoloUp Go Host Earnings" class="withdraw-infographic-img" width="1600" height="600" loading="lazy">
          <div class="step-zoom-badge" aria-label="Zoom image">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FAQs Section -->
  <section class="section section-deep" id="faqs">
    <div class="container">
      <div class="section-title-wrap">
        <h2 class="section-title">Frequently Asked Questions</h2>
      </div>

      <div class="faq-wrap">
        <div class="faq-item">
          <button type="button" class="faq-question" aria-expanded="false">
            <span>1. What is a BoloUp Go Host?</span>
            <span class="faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="faq-answer">
            <p>
              A BoloUp Go Host creates live content and interacts with viewers in real time. Hosts can chat, entertain, share their interests, build an audience, and receive gifts.
            </p>
          </div>
        </div>

        <div class="faq-item">
          <button type="button" class="faq-question" aria-expanded="false">
            <span>2. Do I need an agency to become a BoloUp Go Host?</span>
            <span class="faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="faq-answer">
            <p>
              The current Host registration process includes joining an agency by entering an Agency ID before completing account verification.
            </p>
          </div>
        </div>

        <div class="faq-item">
          <button type="button" class="faq-question" aria-expanded="false">
            <span>3. How does a BoloUp Go Host earn?</span>
            <span class="faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="faq-answer">
            <p>
              Hosts can receive virtual gifts from viewers during their live sessions. Other rewards or incentives may depend on current BoloUp Go and agency program rules.
            </p>
          </div>
        </div>

        <div class="faq-item">
          <button type="button" class="faq-question" aria-expanded="false">
            <span>4. Can I withdraw my own Host earnings?</span>
            <span class="faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="faq-answer">
            <p>
              Yes. Eligible Hosts can request withdrawals directly from their account once their balance meets the applicable requirements.
            </p>
          </div>
        </div>

        <div class="faq-item">
          <button type="button" class="faq-question" aria-expanded="false">
            <span>5. Which withdrawal methods are available?</span>
            <span class="faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="faq-answer">
            <p>
              BoloUp supports several payout options, including bank transfer, e-wallet, Payoneer, and USDT in supported regions. The options shown in your account depend on your location.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- CTA Section -->
  <section class="cta-section" id="cta">
    <div class="container">
      <div class="cta-banner">
        <h2 class="cta-title">Your Next Audience Is Waiting</h2>
        <div class="hero-actions" style="margin-top: 2rem;">
          <a href="#registration" class="btn btn-primary btn-lg" id="cta-start-host">
            Start as a BoloUp Go Host
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- Lightbox Modal -->
  <div class="lightbox-modal" id="lightbox-modal" role="dialog" aria-modal="true" aria-label="Image Preview">
    <div class="lightbox-content">
      <button type="button" class="lightbox-close" id="lightbox-close" aria-label="Close image preview">&times;</button>
      <img src="" alt="" class="lightbox-img" id="lightbox-img">
    </div>
  </div>

  <!-- Internal JavaScript (Per Project Rules) -->
  <script>
    (function () {
      // FAQ Accordion
      const faqItems = document.querySelectorAll('.faq-item');
      faqItems.forEach(function (item) {
        const btn = item.querySelector('.faq-question');
        if (btn) {
          btn.addEventListener('click', function () {
            const isActive = item.classList.contains('active');
            faqItems.forEach(function (other) {
              other.classList.remove('active');
              const otherBtn = other.querySelector('.faq-question');
              if (otherBtn) {
                otherBtn.setAttribute('aria-expanded', 'false');
              }
            });
            if (!isActive) {
              item.classList.add('active');
              btn.setAttribute('aria-expanded', 'true');
            }
          });
        }
      });

      // Lightbox Logic
      const modal = document.getElementById('lightbox-modal');
      const modalImg = document.getElementById('lightbox-img');
      const closeBtn = document.getElementById('lightbox-close');

      window.openLightbox = function (el) {
        const src = el.getAttribute('data-src');
        const alt = el.getAttribute('data-alt') || '';
        if (modal && modalImg && src) {
          modalImg.src = src;
          modalImg.alt = alt;
          modal.classList.add('active');
          document.body.style.overflow = 'hidden';
        }
      };

      function closeLightbox() {
        if (modal) {
          modal.classList.remove('active');
          document.body.style.overflow = '';
          if (modalImg) modalImg.src = '';
        }
      }

      if (closeBtn) closeBtn.addEventListener('click', closeLightbox);
      if (modal) {
        modal.addEventListener('click', function (e) {
          if (e.target === modal) closeLightbox();
        });
      }
      document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && modal && modal.classList.contains('active')) {
          closeLightbox();
        }
      });
    })();
  </script>
</main>
<!-- ==========================================================================
     BoloUp Go Official - Footer Component (footer.html)
     For WordPress Elementor Theme Builder Footer Template
     ========================================================================== -->
<footer class="footer" id="footer">
  <div class="container">
    <div class="footer-grid">
      <!-- Brand Overview -->
      <div class="footer-brand">
        <a href="/" class="brand-logo" id="footer-brand-logo" aria-label="BoloUp Go Home">
          <img src="https://boloupgo.app/wp-content/uploads/2026/11/logo-samping.png" alt="BoloUp Go Official Logo" class="brand-logo-icon" width="914" height="261" loading="lazy">
        </a>
        <p class="footer-desc">
          BoloUp Go is a social space for real-time connection. Bringing live video, voice rooms, conversations, creators, and income together in one place, whether you want to host or build a team behind the scenes.
        </p>
      </div>

      <!-- Navigation Links -->
      <div class="footer-col">
        <h3>Navigation</h3>
        <ul class="footer-links">
          <li><a href="/">Home</a></li>
          <li><a href="/host">Host</a></li>
          <li><a href="/agent">Agent</a></li>
          <li><a href="/contact">Contact</a></li>
        </ul>
      </div>

      <!-- Quick Resources -->
      <div class="footer-col">
        <h3>Host &amp; Agent</h3>
        <ul class="footer-links">
          <li><a href="/host">Become a Host</a></li>
          <li><a href="/host#registration">Host Registration</a></li>
          <li><a href="/agent">Become an Agent</a></li>
          <li><a href="/agent#registration">Agent Registration</a></li>
        </ul>
      </div>

      <!-- Platform Links -->
      <div class="footer-col">
        <h3>BoloUp Go</h3>
        <ul class="footer-links">
          <li><a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer">Download BoloUp Go</a></li>
          <li><a href="/contact">Contact &amp; Support</a></li>
        </ul>
      </div>
    </div>

    <!-- Bottom Bar -->
    <div class="footer-bottom">
      <div>&copy; 2026 BoloUp Go (boloupgo.app). All rights reserved.</div>
      <div>Live, Connect, Discover, and Earn More</div>
    </div>
  </div>
</footer>

<?php
get_footer();

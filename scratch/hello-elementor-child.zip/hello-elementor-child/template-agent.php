<?php
/**
 * Template Name: BoloUp Go Agent Page
 * Template Post Type: page
 */
get_header();
?>
<!-- ==========================================================================
     BoloUp Go Official - Header Component (header.html)
     For WordPress Elementor Theme Builder Header Template
     ========================================================================== -->
<header class="header" id="header">
  <div class="header-container">
    <a href="/" class="brand-logo" id="brand-logo" aria-label="BoloUp Go Official Home">
      <img src="https://boloupgo.app/wp-content/uploads/2026/11/logo-samping.png" alt="BoloUp Go Official Logo"
        class="brand-logo-icon" width="914" height="261">
    </a>

    <nav class="nav-menu" id="nav-menu" aria-label="Main Navigation">
      <a href="/" class="nav-link" id="nav-home">Home</a>
      <a href="/host" class="nav-link" id="nav-host">Host</a>
      <a href="/agent" class="nav-link" id="nav-agent">Agent</a>
      <a href="/contact" class="nav-link" id="nav-contact">Contact</a>
      <div class="mobile-nav-actions">
        <a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer" class="btn btn-outline" id="btn-mobile-download">Download App</a>
        <a href="/host" class="btn btn-primary" id="btn-mobile-host">Become a Host</a>
      </div>
    </nav>

    <div class="header-actions">
      <a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer" class="btn btn-outline btn-sm" id="btn-header-download">Download App</a>
      <a href="/host" class="btn btn-primary btn-sm" id="btn-header-host">Become a Host</a>
      <button type="button" class="menu-toggle" id="menu-toggle" aria-label="Toggle Navigation Menu" aria-expanded="false" aria-controls="nav-menu">&#9776;</button>
    </div>
  </div>
</header>

<script>
  (function () {
    // Set background to deep dark
    document.documentElement.style.setProperty('background-color', '#080718', 'important');
    if (document.body) {
      document.body.style.setProperty('background-color', '#080718', 'important');
    }

    const menuToggle = document.getElementById('menu-toggle');
    const navMenu = document.getElementById('nav-menu');
    if (menuToggle && navMenu) {
      function toggleMenu(open) {
        const shouldOpen = open !== undefined ? open : !navMenu.classList.contains('active');
        navMenu.classList.toggle('active', shouldOpen);
        menuToggle.textContent = shouldOpen ? '✕' : '☰';
        menuToggle.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
      }

      menuToggle.addEventListener('click', function (e) {
        e.stopPropagation();
        toggleMenu();
      });

      // Close menu when clicking outside
      document.addEventListener('click', function (e) {
        if (!navMenu.contains(e.target) && !menuToggle.contains(e.target)) {
          toggleMenu(false);
        }
      });

      // Close menu when a link inside is clicked
      navMenu.querySelectorAll('a').forEach(function (link) {
        link.addEventListener('click', function () {
          toggleMenu(false);
        });
      });

      // Close on Escape key
      document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && navMenu.classList.contains('active')) {
          toggleMenu(false);
        }
      });
    }

    // Highlight current page active link
    const currentPath = window.location.pathname.replace(/\/+$/, '') || '/';
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(function (link) {
      const href = (link.getAttribute('href') || '').replace(/\/+$/, '') || '/';
      if (href === currentPath || (href === '/' && (currentPath === '' || currentPath === '/index.html'))) {
        link.classList.add('active');
      }
    });

    // Fixed Header Lock & Elementor parent container cleanup
    const header = document.getElementById('header');
    if (header) {
      function lockHeaderPosition() {
        header.style.setProperty('position', 'fixed', 'important');
        header.style.setProperty('top', '0px', 'important');
        header.style.setProperty('left', '0px', 'important');
        header.style.setProperty('right', '0px', 'important');
        header.style.setProperty('width', '100%', 'important');
        header.style.setProperty('z-index', '99999', 'important');

        // Check if WordPress admin bar is present and offset top
        const wpAdminBar = document.getElementById('wpadminbar');
        if (wpAdminBar) {
          const barHeight = wpAdminBar.offsetHeight || 32;
          header.style.setProperty('top', barHeight + 'px', 'important');
        }
      }

      window.addEventListener('scroll', lockHeaderPosition, { passive: true });
      window.addEventListener('resize', lockHeaderPosition);
      document.addEventListener('DOMContentLoaded', lockHeaderPosition);
      lockHeaderPosition();
    }
  })();
</script>

<main>
<!-- Hero Section -->
  <section class="hero-section hero-agent" id="hero">
    <div class="container">
      <div class="hero-grid">
        <div class="hero-content">
          <div class="badge-partner">
            <span class="badge-dot"></span>
            BoloUp Go Agency Leadership
          </div>
          <h1 class="hero-title">
            <span class="text-gradient">Build the Team Behind the Live with BoloUp Go Agent</span>
          </h1>
          <p class="hero-desc">
            Prefer building a team instead of the livestreaming spotlight? As a BoloUp Go Agent, you can recruit promising Hosts, guide them, manage your team, and create earning opportunities with the team you build.
          </p>
          <div class="hero-actions">
            <a href="#registration" class="btn btn-primary btn-lg" id="hero-cta-agent">
              Become a BoloUp Go Agent
            </a>
            <a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer"
              class="btn btn-outline btn-lg" id="hero-cta-download">
              Download App
            </a>
          </div>
        </div>

        <div class="hero-visual" id="hero-visual-agent">
          <div class="hero-visual-frame">
            <img src="https://boloupgo.app/wp-content/uploads/2026/11/boloup-agent-full.png"
              alt="Build the Team Behind the Live with BoloUp Go Agent" class="hero-img" width="1458" height="1210"
              fetchpriority="high">
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- BoloUp Go Agent Benefits Section -->
  <section class="section section-dark" id="benefits">
    <div class="container">
      <div class="section-title-wrap">
        <h2 class="section-title">Build People. Grow a Network. Create Opportunities.</h2>
      </div>

      <div class="benefits-grid">
        <div class="benefit-card" id="benefit-network">
          <div class="feature-icon-box">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24" aria-hidden="true">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
              <path d="M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          </div>
          <h3 class="benefit-title">1. Create Your Own Host Network</h3>
          <p class="benefit-desc">
            Find creators with potential and bring them together under one agency you can manage and develop over time.
          </p>
        </div>

        <div class="benefit-card" id="benefit-grow-team">
          <div class="feature-icon-box accent">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24" aria-hidden="true">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
            </svg>
          </div>
          <h3 class="benefit-title">2. Grow Through Your Team</h3>
          <p class="benefit-desc">
            Your progress as an Agent is connected to eligible activity from the Hosts and network you manage, giving team growth a real purpose.
          </p>
        </div>

        <div class="benefit-card" id="benefit-support-stream">
          <div class="feature-icon-box pink">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24" aria-hidden="true">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            </svg>
          </div>
          <h3 class="benefit-title">3. Be the Support Behind the Stream</h3>
          <p class="benefit-desc">
            Help Hosts understand the platform, stay active, solve challenges, and build stronger live experiences for their viewers.
          </p>
        </div>
      </div>
    </div>
  </section>

  <!-- Registration Tutorial Section -->
  <section class="section section-deep" id="registration">
    <div class="container">
      <div class="section-title-wrap">
        <h2 class="section-title">How to Register as a BoloUp Go Agent</h2>
      </div>

      <div class="steps-alternate" id="agent-registration-steps">
        <!-- Step 1 -->
        <div class="step-alt-row" id="agent-reg-step-1">
          <div class="step-alt-visual" onclick="openLightbox(this)" data-src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Agency-Registration-Step-1-1.png" data-alt="How to Register as a BoloUp Go Agent - Step 1">
            <div class="step-alt-frame">
              <img src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Agency-Registration-Step-1-1.png"
                alt="How to Register as a BoloUp Go Agent - Step 1" width="513" height="912" loading="lazy" class="step-alt-img">
              <div class="step-zoom-badge" aria-label="Zoom image">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>
              </div>
            </div>
          </div>
          <div class="step-alt-content">
            <div class="step-number">1</div>
            <h3 class="step-title">Step 1 – Download BoloUp Go</h3>
            <p class="step-desc">
              Install the app <a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer" style="color: var(--color-primary-light); text-decoration: underline;">via this link</a> and open it to begin creating your account.
            </p>
          </div>
        </div>

        <!-- Step 2 -->
        <div class="step-alt-row step-alt-reverse" id="agent-reg-step-2">
          <div class="step-alt-visual" onclick="openLightbox(this)" data-src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Agency-Registration-Step-2-1.png" data-alt="How to Register as a BoloUp Go Agent - Step 2">
            <div class="step-alt-frame">
              <img src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Agency-Registration-Step-2-1.png"
                alt="How to Register as a BoloUp Go Agent - Step 2" width="513" height="912" loading="lazy" class="step-alt-img">
              <div class="step-zoom-badge" aria-label="Zoom image">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>
              </div>
            </div>
          </div>
          <div class="step-alt-content">
            <div class="step-number accent">2</div>
            <h3 class="step-title">Step 2 – Create Your Account</h3>
            <p class="step-desc">
              Register using one of the available sign-in methods and complete the basic profile information requested in the app.
            </p>
          </div>
        </div>

        <!-- Step 3 -->
        <div class="step-alt-row" id="agent-reg-step-3">
          <div class="step-alt-visual" onclick="openLightbox(this)" data-src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Agency-Registration-Step-3-1.png" data-alt="How to Register as a BoloUp Go Agent - Step 3">
            <div class="step-alt-frame">
              <img src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Agency-Registration-Step-3-1.png"
                alt="How to Register as a BoloUp Go Agent - Step 3" width="513" height="912" loading="lazy" class="step-alt-img">
              <div class="step-zoom-badge" aria-label="Zoom image">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>
              </div>
            </div>
          </div>
          <div class="step-alt-content">
            <div class="step-number">3</div>
            <h3 class="step-title">Step 3 – Complete Face Verification</h3>
            <p class="step-desc">
              Open your profile, go to the Authentication Center, and follow the instructions shown on screen to complete verification.
            </p>
          </div>
        </div>

        <!-- Step 4 -->
        <div class="step-alt-row step-alt-reverse" id="agent-reg-step-4">
          <div class="step-alt-visual" onclick="openLightbox(this)" data-src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Agency-Registration-Step-4.jpg" data-alt="How to Register as a BoloUp Go Agent - Step 4">
            <div class="step-alt-frame">
              <img src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-Agency-Registration-Step-4.jpg"
                alt="How to Register as a BoloUp Go Agent - Step 4" width="444" height="912" loading="lazy" class="step-alt-img">
              <div class="step-zoom-badge" aria-label="Zoom image">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>
              </div>
            </div>
          </div>
          <div class="step-alt-content">
            <div class="step-number accent">4</div>
            <h3 class="step-title">Step 4 – Open the Agency Invitation</h3>
            <p class="step-desc">
              Access the agency invitation link provided to you (contact us for the link). If the invitation prompt does not appear immediately, check System Messages inside BoloUp Go.
            </p>
          </div>
        </div>

        <!-- Step 5 -->
        <div class="step-alt-row" id="agent-reg-step-5">
          <div class="step-alt-content" style="max-width: 100%;">
            <div class="step-number">5</div>
            <h3 class="step-title">Step 5 – Review the Agency Details</h3>
            <p class="step-desc">
              Make sure the agency information shown in the invitation is correct before continuing.
            </p>
          </div>
        </div>

        <!-- Step 6 -->
        <div class="step-alt-row" id="agent-reg-step-6">
          <div class="step-alt-content" style="max-width: 100%;">
            <div class="step-number accent">6</div>
            <h3 class="step-title">Step 6 – Accept the Invitation</h3>
            <p class="step-desc">
              Confirm the invitation to complete your Agent registration and begin accessing your agency features.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Withdraw Tutorial Section -->
  <section class="section section-dark" id="withdraw">
    <div class="container">
      <div class="section-title-wrap">
        <h2 class="section-title">How to Withdraw as a BoloUp Go Agent</h2>
      </div>

      <div class="steps-grid">
        <div class="step-card" id="agent-withdraw-step-1">
          <div class="step-number">1</div>
          <h3 class="step-title">Step 1 – Open Your Profile</h3>
          <p class="step-desc">
            Log in to BoloUp Go and go to your profile page.
          </p>
        </div>

        <div class="step-card" id="agent-withdraw-step-2">
          <div class="step-number accent">2</div>
          <h3 class="step-title">Step 2 – Enter the Diamonds Section</h3>
          <p class="step-desc">
            Tap Diamonds to view your eligible balance and withdrawal settings.
          </p>
        </div>

        <div class="step-card" id="agent-withdraw-step-3">
          <div class="step-number">3</div>
          <h3 class="step-title">Step 3 – Select Withdraw Method</h3>
          <p class="step-desc">
            Open Withdraw Method to see the payout options currently available for your account and region.
          </p>
        </div>

        <div class="step-card" id="agent-withdraw-step-4">
          <div class="step-number accent">4</div>
          <h3 class="step-title">Step 4 – Choose a Payout Option</h3>
          <p class="step-desc">
            Select one of the available methods, which may include bank transfer, e-wallet, Payoneer, or USDT depending on your location.
          </p>
        </div>

        <div class="step-card" id="agent-withdraw-step-5">
          <div class="step-number">5</div>
          <h3 class="step-title">Step 5 – Add Your Payment Details</h3>
          <p class="step-desc">
            Tap Withdrawal Info and carefully connect the payout account you want to use.
          </p>
        </div>

        <div class="step-card" id="agent-withdraw-step-6">
          <div class="step-number accent">6</div>
          <h3 class="step-title">Step 6 – Enter the Amount</h3>
          <p class="step-desc">
            Choose the amount you want to withdraw. Make sure your eligible balance meets the current minimum withdrawal requirement.
          </p>
        </div>

        <div class="step-card" id="agent-withdraw-step-7">
          <div class="step-number">7</div>
          <h3 class="step-title">Step 7 – Review and Submit</h3>
          <p class="step-desc">
            Check the amount and payment information one more time, then tap Withdraw to send your request.
          </p>
        </div>
      </div>

      <!-- Withdraw Infographic Banner -->
      <div class="withdraw-infographic-wrap">
        <div class="withdraw-infographic-card" onclick="openLightbox(this)" data-src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-AgentHost-Withdraw.jpg" data-alt="How to Withdraw as a BoloUp Go Agent">
          <img src="https://boloupgo.app/wp-content/uploads/2026/11/BoloUp-AgentHost-Withdraw.jpg"
            alt="How to Withdraw as a BoloUp Go Agent" class="withdraw-infographic-img" width="1600" height="600" loading="lazy">
          <div class="step-zoom-badge" aria-label="Zoom image">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Invite Host Tutorial Section -->
  <section class="section section-deep" id="invite-host">
    <div class="container">
      <div class="section-title-wrap">
        <h2 class="section-title">Turn Connections into a Growing Host Team</h2>
      </div>

      <div class="steps-alternate" id="agent-invite-steps">
        <!-- Step 1 & 2 & 3: Part 1 visual -->
        <div class="step-alt-row" id="invite-step-1">
          <div class="step-alt-visual" onclick="openLightbox(this)" data-src="https://boloupgo.app/wp-content/uploads/2026/11/boloup-agent-add-new-host-part-1.jpg" data-alt="Turn Connections into a Growing Host Team - Invite Link">
            <div class="step-alt-frame">
              <img src="https://boloupgo.app/wp-content/uploads/2026/11/boloup-agent-add-new-host-part-1.jpg"
                alt="Turn Connections into a Growing Host Team - Invite Link" width="1093" height="820" loading="lazy" class="step-alt-img">
              <div class="step-zoom-badge" aria-label="Zoom image">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>
              </div>
            </div>
          </div>
          <div class="step-alt-content">
            <div class="step-number">1</div>
            <h3 class="step-title">Step 1 – Open My Agency</h3>
            <p class="step-desc">
              Go to your profile and tap My Agency to enter your Agent dashboard.
            </p>
            <div style="margin-top: 1.5rem;">
              <div class="step-number accent">2</div>
              <h3 class="step-title">Step 2 – Choose Host Invite (Link)</h3>
              <p class="step-desc">
                Select Host Invite (Link) to generate an invitation for potential Hosts.
              </p>
            </div>
            <div style="margin-top: 1.5rem;">
              <div class="step-number">3</div>
              <h3 class="step-title">Step 3 – Copy Your Invitation Link</h3>
              <p class="step-desc">
                Copy the link provided by BoloUp Go.
              </p>
            </div>
          </div>
        </div>

        <!-- Step 4 -->
        <div class="step-alt-row step-alt-reverse" id="invite-step-4">
          <div class="step-alt-content" style="max-width: 100%;">
            <div class="step-number accent">4</div>
            <h3 class="step-title">Step 4 – Share It with Potential Hosts</h3>
            <p class="step-desc">
              Send your invitation through messaging apps, social media, or directly to people you want to recruit.
            </p>
          </div>
        </div>

        <!-- Step 5 & 6: Part 2 visual -->
        <div class="step-alt-row" id="invite-step-5">
          <div class="step-alt-visual" onclick="openLightbox(this)" data-src="https://boloupgo.app/wp-content/uploads/2026/11/boloup-agent-add-new-host-part-2.jpg" data-alt="Turn Connections into a Growing Host Team - Invite by ID">
            <div class="step-alt-frame">
              <img src="https://boloupgo.app/wp-content/uploads/2026/11/boloup-agent-add-new-host-part-2.jpg"
                alt="Turn Connections into a Growing Host Team - Invite by ID" width="1097" height="830" loading="lazy" class="step-alt-img">
              <div class="step-zoom-badge" aria-label="Zoom image">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>
              </div>
            </div>
          </div>
          <div class="step-alt-content">
            <div class="step-number">5</div>
            <h3 class="step-title">Step 5 – Invite a Specific Host by ID</h3>
            <p class="step-desc">
              For a direct invitation, choose Host Invite (ID) instead.
            </p>
            <div style="margin-top: 1.5rem;">
              <div class="step-number accent">6</div>
              <h3 class="step-title">Step 6 – Enter the Host Details</h3>
              <p class="step-desc">
                Add the Host ID and verification code provided by the Host, check that the information is correct, and submit the invitation.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FAQs Section -->
  <section class="section section-dark" id="faqs">
    <div class="container">
      <div class="section-title-wrap">
        <h2 class="section-title">Frequently Asked Questions</h2>
      </div>

      <div class="faq-wrap">
        <div class="faq-item">
          <button type="button" class="faq-question" aria-expanded="false">
            <span>1. What does a BoloUp Go Agent do?</span>
            <span class="faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="faq-answer">
            <p>
              A BoloUp Go Agent focuses on recruiting, managing, and supporting Hosts. The role is less about being on camera and more about helping a network of creators stay active and grow.
            </p>
          </div>
        </div>

        <div class="faq-item">
          <button type="button" class="faq-question" aria-expanded="false">
            <span>2. How can a BoloUp Go Agent earn?</span>
            <span class="faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="faq-answer">
            <p>
              Agent earnings can come from eligible commissions connected to Host activity, Host earnings, and other network activity covered by the current BoloUp agency program. Actual earnings depend on performance and applicable program rules.
            </p>
          </div>
        </div>

        <div class="faq-item">
          <button type="button" class="faq-question" aria-expanded="false">
            <span>3. Can I invite a Host who already belongs to another agency?</span>
            <span class="faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="faq-answer">
            <p>
              Not immediately. A Host who is already part of another agency must first complete the process of leaving that agency before joining a new one.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- CTA Section -->
  <section class="cta-section" id="cta">
    <div class="container">
      <div class="cta-banner">
        <h2 class="cta-title">Great Hosts Need a Strong Support</h2>
        <div class="hero-actions" style="margin-top: 2rem;">
          <a href="#registration" class="btn btn-primary btn-lg" id="cta-start-agent">
            Start as a BoloUp Go Agent
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- Lightbox Modal -->
  <div class="lightbox-modal" id="lightbox-modal" role="dialog" aria-modal="true" aria-label="Image Preview">
    <div class="lightbox-content">
      <button type="button" class="lightbox-close" id="lightbox-close" aria-label="Close image preview">&times;</button>
      <img src="" alt="" class="lightbox-img" id="lightbox-img">
    </div>
  </div>

  <!-- Internal JavaScript (Per Project Rules) -->
  <script>
    (function () {
      // FAQ Accordion
      const faqItems = document.querySelectorAll('.faq-item');
      faqItems.forEach(function (item) {
        const btn = item.querySelector('.faq-question');
        if (btn) {
          btn.addEventListener('click', function () {
            const isActive = item.classList.contains('active');
            faqItems.forEach(function (other) {
              other.classList.remove('active');
              const otherBtn = other.querySelector('.faq-question');
              if (otherBtn) {
                otherBtn.setAttribute('aria-expanded', 'false');
              }
            });
            if (!isActive) {
              item.classList.add('active');
              btn.setAttribute('aria-expanded', 'true');
            }
          });
        }
      });

      // Lightbox Logic
      const modal = document.getElementById('lightbox-modal');
      const modalImg = document.getElementById('lightbox-img');
      const closeBtn = document.getElementById('lightbox-close');

      window.openLightbox = function (el) {
        const src = el.getAttribute('data-src');
        const alt = el.getAttribute('data-alt') || '';
        if (modal && modalImg && src) {
          modalImg.src = src;
          modalImg.alt = alt;
          modal.classList.add('active');
          document.body.style.overflow = 'hidden';
        }
      };

      function closeLightbox() {
        if (modal) {
          modal.classList.remove('active');
          document.body.style.overflow = '';
          if (modalImg) modalImg.src = '';
        }
      }

      if (closeBtn) closeBtn.addEventListener('click', closeLightbox);
      if (modal) {
        modal.addEventListener('click', function (e) {
          if (e.target === modal) closeLightbox();
        });
      }
      document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && modal && modal.classList.contains('active')) {
          closeLightbox();
        }
      });
    })();
  </script>
</main>
<!-- ==========================================================================
     BoloUp Go Official - Footer Component (footer.html)
     For WordPress Elementor Theme Builder Footer Template
     ========================================================================== -->
<footer class="footer" id="footer">
  <div class="container">
    <div class="footer-grid">
      <!-- Brand Overview -->
      <div class="footer-brand">
        <a href="/" class="brand-logo" id="footer-brand-logo" aria-label="BoloUp Go Home">
          <img src="https://boloupgo.app/wp-content/uploads/2026/11/logo-samping.png" alt="BoloUp Go Official Logo" class="brand-logo-icon" width="914" height="261" loading="lazy">
        </a>
        <p class="footer-desc">
          BoloUp Go is a social space for real-time connection. Bringing live video, voice rooms, conversations, creators, and income together in one place, whether you want to host or build a team behind the scenes.
        </p>
      </div>

      <!-- Navigation Links -->
      <div class="footer-col">
        <h3>Navigation</h3>
        <ul class="footer-links">
          <li><a href="/">Home</a></li>
          <li><a href="/host">Host</a></li>
          <li><a href="/agent">Agent</a></li>
          <li><a href="/contact">Contact</a></li>
        </ul>
      </div>

      <!-- Quick Resources -->
      <div class="footer-col">
        <h3>Host &amp; Agent</h3>
        <ul class="footer-links">
          <li><a href="/host">Become a Host</a></li>
          <li><a href="/host#registration">Host Registration</a></li>
          <li><a href="/agent">Become an Agent</a></li>
          <li><a href="/agent#registration">Agent Registration</a></li>
        </ul>
      </div>

      <!-- Platform Links -->
      <div class="footer-col">
        <h3>BoloUp Go</h3>
        <ul class="footer-links">
          <li><a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer">Download BoloUp Go</a></li>
          <li><a href="/contact">Contact &amp; Support</a></li>
        </ul>
      </div>
    </div>

    <!-- Bottom Bar -->
    <div class="footer-bottom">
      <div>&copy; 2026 BoloUp Go (boloupgo.app). All rights reserved.</div>
      <div>Live, Connect, Discover, and Earn More</div>
    </div>
  </div>
</footer>

<?php
get_footer();

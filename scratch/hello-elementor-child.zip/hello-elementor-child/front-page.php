<?php
/**
 * Front Page Template for BoloUp Go
 */
get_header();
?>
<!-- ==========================================================================
     BoloUp Go Official - Header Component (header.html)
     For WordPress Elementor Theme Builder Header Template
     ========================================================================== -->
<header class="header" id="header">
  <div class="header-container">
    <a href="/" class="brand-logo" id="brand-logo" aria-label="BoloUp Go Official Home">
      <img src="https://boloupgo.app/wp-content/uploads/2026/11/logo-samping.png" alt="BoloUp Go Official Logo"
        class="brand-logo-icon" width="914" height="261">
    </a>

    <nav class="nav-menu" id="nav-menu" aria-label="Main Navigation">
      <a href="/" class="nav-link" id="nav-home">Home</a>
      <a href="/host" class="nav-link" id="nav-host">Host</a>
      <a href="/agent" class="nav-link" id="nav-agent">Agent</a>
      <a href="/contact" class="nav-link" id="nav-contact">Contact</a>
      <div class="mobile-nav-actions">
        <a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer" class="btn btn-outline" id="btn-mobile-download">Download App</a>
        <a href="/host" class="btn btn-primary" id="btn-mobile-host">Become a Host</a>
      </div>
    </nav>

    <div class="header-actions">
      <a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer" class="btn btn-outline btn-sm" id="btn-header-download">Download App</a>
      <a href="/host" class="btn btn-primary btn-sm" id="btn-header-host">Become a Host</a>
      <button type="button" class="menu-toggle" id="menu-toggle" aria-label="Toggle Navigation Menu" aria-expanded="false" aria-controls="nav-menu">&#9776;</button>
    </div>
  </div>
</header>

<script>
  (function () {
    // Set background to deep dark
    document.documentElement.style.setProperty('background-color', '#080718', 'important');
    if (document.body) {
      document.body.style.setProperty('background-color', '#080718', 'important');
    }

    const menuToggle = document.getElementById('menu-toggle');
    const navMenu = document.getElementById('nav-menu');
    if (menuToggle && navMenu) {
      function toggleMenu(open) {
        const shouldOpen = open !== undefined ? open : !navMenu.classList.contains('active');
        navMenu.classList.toggle('active', shouldOpen);
        menuToggle.textContent = shouldOpen ? '✕' : '☰';
        menuToggle.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
      }

      menuToggle.addEventListener('click', function (e) {
        e.stopPropagation();
        toggleMenu();
      });

      // Close menu when clicking outside
      document.addEventListener('click', function (e) {
        if (!navMenu.contains(e.target) && !menuToggle.contains(e.target)) {
          toggleMenu(false);
        }
      });

      // Close menu when a link inside is clicked
      navMenu.querySelectorAll('a').forEach(function (link) {
        link.addEventListener('click', function () {
          toggleMenu(false);
        });
      });

      // Close on Escape key
      document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && navMenu.classList.contains('active')) {
          toggleMenu(false);
        }
      });
    }

    // Highlight current page active link
    const currentPath = window.location.pathname.replace(/\/+$/, '') || '/';
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(function (link) {
      const href = (link.getAttribute('href') || '').replace(/\/+$/, '') || '/';
      if (href === currentPath || (href === '/' && (currentPath === '' || currentPath === '/index.html'))) {
        link.classList.add('active');
      }
    });

    // Fixed Header Lock & Elementor parent container cleanup
    const header = document.getElementById('header');
    if (header) {
      function lockHeaderPosition() {
        header.style.setProperty('position', 'fixed', 'important');
        header.style.setProperty('top', '0px', 'important');
        header.style.setProperty('left', '0px', 'important');
        header.style.setProperty('right', '0px', 'important');
        header.style.setProperty('width', '100%', 'important');
        header.style.setProperty('z-index', '99999', 'important');

        // Check if WordPress admin bar is present and offset top
        const wpAdminBar = document.getElementById('wpadminbar');
        if (wpAdminBar) {
          const barHeight = wpAdminBar.offsetHeight || 32;
          header.style.setProperty('top', barHeight + 'px', 'important');
        }
      }

      window.addEventListener('scroll', lockHeaderPosition, { passive: true });
      window.addEventListener('resize', lockHeaderPosition);
      document.addEventListener('DOMContentLoaded', lockHeaderPosition);
      lockHeaderPosition();
    }
  })();
</script>

<main>
<!-- Hero Section -->
  <section class="hero-section hero-home" id="hero">
    <div class="container">
      <div class="hero-grid">
        <div class="hero-content">
          <div class="badge-partner">
            <span class="badge-dot"></span>
            BoloUp Go Social Space
          </div>
          <h1 class="hero-title">
            <span class="text-gradient">Live More. Connect More. Discover BoloUp Go.</span>
          </h1>
          <p class="hero-desc">
            BoloUp Go is a social space for real-time connection. Bringing live video, voice rooms, conversations, creators, and income together in one place, whether you want to host or build a team behind the scenes.
          </p>
          <div class="hero-actions">
            <a href="#what-is-boloup" class="btn btn-primary btn-lg" id="hero-cta-explore">
              Explore BoloUp Go
            </a>
            <a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer"
              class="btn btn-outline btn-lg" id="hero-cta-download">
              Download App
            </a>
          </div>
        </div>

        <div class="hero-visual" id="hero-visual-home">
          <div class="hero-visual-frame">
            <img src="https://boloupgo.app/wp-content/uploads/2026/11/boloupgo-hero.png"
              alt="Live More. Connect More. Discover BoloUp Go." class="hero-img" width="1243" height="1266"
              fetchpriority="high">
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- What is BoloUp Section -->
  <section class="section section-dark" id="what-is-boloup">
    <div class="container">
      <div class="section-title-wrap">
        <h2 class="section-title">BoloUp Go Happens Live</h2>
        <p class="section-desc">
          BoloUp Go is a social entertainment app where people can meet, talk, watch live content, and share moments as they happen.
        </p>
        <p class="section-desc">
          Join a live room, discover new creators, take part in conversations, send gifts, or simply find people who share your interests. For users who want to go further, BoloUp Go also offers opportunities to participate as a Host or Agent.
        </p>
      </div>
    </div>
  </section>

  <!-- Host vs Agent Comparison Section -->
  <section class="section section-deep" id="host-vs-agent">
    <div class="container">
      <div class="section-title-wrap">
        <h2 class="section-title">Host or Agent: Choose How You Want to Grow</h2>
      </div>

      <div class="table-wrapper">
        <div class="table-responsive">
          <table class="data-table" id="table-comparison">
            <thead>
              <tr>
                <th scope="col">Role</th>
                <th scope="col">BoloUp Go Host</th>
                <th scope="col">BoloUp Go Agent</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>Main Role</strong></td>
                <td>Creates live content and interacts directly with viewers.</td>
                <td>Builds, manages, and supports a team of Hosts.</td>
              </tr>
              <tr>
                <td><strong>Best For</strong></td>
                <td>People who enjoy being on camera, entertaining, talking, or sharing their interests.</td>
                <td>People who enjoy recruiting talent, building teams, and supporting creators.</td>
              </tr>
              <tr>
                <td><strong>Growth Focus</strong></td>
                <td>Growing an audience and creating stronger viewer engagement.</td>
                <td>Growing an active Host team and developing agency performance.</td>
              </tr>
              <tr>
                <td><strong>Opportunity</strong></td>
                <td>Receive support through viewer interaction and eligible Host programs.</td>
                <td>Access agency opportunities, events, and rewards.</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>

  <!-- Features Section -->
  <section class="section section-dark" id="features">
    <div class="container">
      <div class="section-title-wrap">
        <h2 class="section-title">More Ways to Connect on BoloUp Go</h2>
      </div>

      <div class="features-grid">
        <div class="feature-card" id="feature-live-video">
          <div class="feature-icon-box">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24" aria-hidden="true">
              <path d="m22 8-6 4 6 4V8Z" />
              <rect width="14" height="12" x="2" y="6" rx="2" />
            </svg>
          </div>
          <h3 class="feature-title">1. Live Video</h3>
          <p class="feature-desc">
            Discover live broadcasts, join conversations, play games, and experience moments as they happen.
          </p>
        </div>

        <div class="feature-card" id="feature-voice-rooms">
          <div class="feature-icon-box accent">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24" aria-hidden="true">
              <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
              <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
              <line x1="12" y1="19" x2="12" y2="22" />
            </svg>
          </div>
          <h3 class="feature-title">2. Voice Rooms and Chat</h3>
          <p class="feature-desc">
            Not every connection needs a camera. Join voice rooms, chat with other users, and keep conversations going beyond the live stream.
          </p>
        </div>

        <div class="feature-card" id="feature-gifts-interactive">
          <div class="feature-icon-box pink">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24" aria-hidden="true">
              <rect x="3" y="8" width="18" height="4" rx="1" />
              <path d="M12 8v13" />
              <path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7" />
              <path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5" />
            </svg>
          </div>
          <h3 class="feature-title">3. Gifts and Interactive Experiences</h3>
          <p class="feature-desc">
            Make live moments more expressive with gifts, visual effects, social activities, and various interactive features available inside the app.
          </p>
        </div>
      </div>
    </div>
  </section>

  <!-- Benefits Section -->
  <section class="section section-deep" id="benefits">
    <div class="container">
      <div class="section-title-wrap">
        <h2 class="section-title">Why People Join BoloUp Go</h2>
      </div>

      <div class="benefits-grid">
        <div class="benefit-card" id="benefit-community">
          <div class="feature-icon-box">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24" aria-hidden="true">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
              <path d="M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          </div>
          <h3 class="benefit-title">1. Find Your Kind of Community</h3>
          <p class="benefit-desc">
            From casual conversations to live entertainment, BoloUp Go gives you different ways to discover people and content that match your interests.
          </p>
        </div>

        <div class="benefit-card" id="benefit-opportunity">
          <div class="feature-icon-box accent">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24" aria-hidden="true">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
            </svg>
          </div>
          <h3 class="benefit-title">2. Turn Participation into Opportunity</h3>
          <p class="benefit-desc">
            Users who want a more active role can explore becoming a Host or building a network as an Agent.
          </p>
        </div>

        <div class="benefit-card" id="benefit-connect-earn">
          <div class="feature-icon-box pink">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="24" height="24" aria-hidden="true">
              <line x1="12" y1="1" x2="12" y2="23" />
              <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
            </svg>
          </div>
          <h3 class="benefit-title">3. Connect &amp; Earn in Your Own Way</h3>
          <p class="benefit-desc">
            Watch, talk, chat, host, or manage a team. BoloUp Go gives different types of users room to participate in ways that fit them.
          </p>
        </div>
      </div>
    </div>
  </section>

  <!-- How it Works Section -->
  <section class="section section-dark" id="how-it-works">
    <div class="container">
      <div class="section-title-wrap">
        <h2 class="section-title">Getting Started with BoloUp Go Is Simple</h2>
      </div>

      <div class="steps-grid">
        <div class="step-card" id="step-download-join">
          <div class="step-number">1</div>
          <h3 class="step-title">Step 1 – Download and Join</h3>
          <p class="step-desc">
            Install BoloUp Go, create your account.
          </p>
        </div>

        <div class="step-card" id="step-explore-community">
          <div class="step-number accent">2</div>
          <h3 class="step-title">Step 2 – Explore the Community</h3>
          <p class="step-desc">
            Watch live streams, join rooms, and discover hosts
          </p>
        </div>

        <div class="step-card" id="step-choose-next">
          <div class="step-number">3</div>
          <h3 class="step-title">Step 3 – Choose Your Next Step</h3>
          <p class="step-desc">
            Explore the dedicated Host and Agent opportunities.
          </p>
        </div>
      </div>
    </div>
  </section>

  <!-- FAQs Section -->
  <section class="section section-deep" id="faqs">
    <div class="container">
      <div class="section-title-wrap">
        <h2 class="section-title">Frequently Asked Questions</h2>
      </div>

      <div class="faq-wrap">
        <div class="faq-item">
          <button type="button" class="faq-question" aria-expanded="false">
            <span>1. What is BoloUp Go?</span>
            <span class="faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="faq-answer">
            <p>
              BoloUp Go is a social entertainment app built around live video, voice rooms, chat, gifts, and interactive experiences that help people connect in real time.
            </p>
          </div>
        </div>

        <div class="faq-item">
          <button type="button" class="faq-question" aria-expanded="false">
            <span>2. What is the difference between a BoloUp Go Host and Agent?</span>
            <span class="faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="faq-answer">
            <p>
              A Host focuses on creating live content and interacting with viewers, while an Agent focuses on recruiting, managing, and supporting Hosts within an agency network.
            </p>
          </div>
        </div>

        <div class="faq-item">
          <button type="button" class="faq-question" aria-expanded="false">
            <span>3. Do I have to become a Host or Agent to use BoloUp Go?</span>
            <span class="faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="faq-answer">
            <p>
              No. You can use BoloUp Go to explore live content, join conversations, chat, and interact with other users. Host and Agent roles are additional options for people who want to participate more actively.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- CTA Section -->
  <section class="cta-section" id="cta">
    <div class="container">
      <div class="cta-banner">
        <h2 class="cta-title">There’s More Than One Way to Be Part of BoloUp Go</h2>
        <div class="hero-actions" style="margin-top: 2rem;">
          <a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer"
            class="btn btn-primary btn-lg" id="cta-get-started">
            Get Started with BoloUp Go
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- Internal JavaScript (Per Project Rules) -->
  <script>
    (function () {
      // FAQ Accordion
      const faqItems = document.querySelectorAll('.faq-item');
      faqItems.forEach(function (item) {
        const btn = item.querySelector('.faq-question');
        if (btn) {
          btn.addEventListener('click', function () {
            const isActive = item.classList.contains('active');
            faqItems.forEach(function (other) {
              other.classList.remove('active');
              const otherBtn = other.querySelector('.faq-question');
              if (otherBtn) {
                otherBtn.setAttribute('aria-expanded', 'false');
              }
            });
            if (!isActive) {
              item.classList.add('active');
              btn.setAttribute('aria-expanded', 'true');
            }
          });
        }
      });
    })();
  </script>
</main>
<!-- ==========================================================================
     BoloUp Go Official - Footer Component (footer.html)
     For WordPress Elementor Theme Builder Footer Template
     ========================================================================== -->
<footer class="footer" id="footer">
  <div class="container">
    <div class="footer-grid">
      <!-- Brand Overview -->
      <div class="footer-brand">
        <a href="/" class="brand-logo" id="footer-brand-logo" aria-label="BoloUp Go Home">
          <img src="https://boloupgo.app/wp-content/uploads/2026/11/logo-samping.png" alt="BoloUp Go Official Logo" class="brand-logo-icon" width="914" height="261" loading="lazy">
        </a>
        <p class="footer-desc">
          BoloUp Go is a social space for real-time connection. Bringing live video, voice rooms, conversations, creators, and income together in one place, whether you want to host or build a team behind the scenes.
        </p>
      </div>

      <!-- Navigation Links -->
      <div class="footer-col">
        <h3>Navigation</h3>
        <ul class="footer-links">
          <li><a href="/">Home</a></li>
          <li><a href="/host">Host</a></li>
          <li><a href="/agent">Agent</a></li>
          <li><a href="/contact">Contact</a></li>
        </ul>
      </div>

      <!-- Quick Resources -->
      <div class="footer-col">
        <h3>Host &amp; Agent</h3>
        <ul class="footer-links">
          <li><a href="/host">Become a Host</a></li>
          <li><a href="/host#registration">Host Registration</a></li>
          <li><a href="/agent">Become an Agent</a></li>
          <li><a href="/agent#registration">Agent Registration</a></li>
        </ul>
      </div>

      <!-- Platform Links -->
      <div class="footer-col">
        <h3>BoloUp Go</h3>
        <ul class="footer-links">
          <li><a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer">Download BoloUp Go</a></li>
          <li><a href="/contact">Contact &amp; Support</a></li>
        </ul>
      </div>
    </div>

    <!-- Bottom Bar -->
    <div class="footer-bottom">
      <div>&copy; 2026 BoloUp Go (boloupgo.app). All rights reserved.</div>
      <div>Live, Connect, Discover, and Earn More</div>
    </div>
  </div>
</footer>

<?php
get_footer();

<?php
/**
 * Template Name: BoloUp Go Contact Page
 * Template Post Type: page
 */
get_header();
?>
<!-- ==========================================================================
     BoloUp Go Official - Header Component (header.html)
     For WordPress Elementor Theme Builder Header Template
     ========================================================================== -->
<header class="header" id="header">
  <div class="header-container">
    <a href="/" class="brand-logo" id="brand-logo" aria-label="BoloUp Go Official Home">
      <img src="https://boloupgo.app/wp-content/uploads/2026/11/logo-samping.png" alt="BoloUp Go Official Logo"
        class="brand-logo-icon" width="914" height="261">
    </a>

    <nav class="nav-menu" id="nav-menu" aria-label="Main Navigation">
      <a href="/" class="nav-link" id="nav-home">Home</a>
      <a href="/host" class="nav-link" id="nav-host">Host</a>
      <a href="/agent" class="nav-link" id="nav-agent">Agent</a>
      <a href="/contact" class="nav-link" id="nav-contact">Contact</a>
      <div class="mobile-nav-actions">
        <a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer" class="btn btn-outline" id="btn-mobile-download">Download App</a>
        <a href="/host" class="btn btn-primary" id="btn-mobile-host">Become a Host</a>
      </div>
    </nav>

    <div class="header-actions">
      <a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer" class="btn btn-outline btn-sm" id="btn-header-download">Download App</a>
      <a href="/host" class="btn btn-primary btn-sm" id="btn-header-host">Become a Host</a>
      <button type="button" class="menu-toggle" id="menu-toggle" aria-label="Toggle Navigation Menu" aria-expanded="false" aria-controls="nav-menu">&#9776;</button>
    </div>
  </div>
</header>

<script>
  (function () {
    // Set background to deep dark
    document.documentElement.style.setProperty('background-color', '#080718', 'important');
    if (document.body) {
      document.body.style.setProperty('background-color', '#080718', 'important');
    }

    const menuToggle = document.getElementById('menu-toggle');
    const navMenu = document.getElementById('nav-menu');
    if (menuToggle && navMenu) {
      function toggleMenu(open) {
        const shouldOpen = open !== undefined ? open : !navMenu.classList.contains('active');
        navMenu.classList.toggle('active', shouldOpen);
        menuToggle.textContent = shouldOpen ? '✕' : '☰';
        menuToggle.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
      }

      menuToggle.addEventListener('click', function (e) {
        e.stopPropagation();
        toggleMenu();
      });

      // Close menu when clicking outside
      document.addEventListener('click', function (e) {
        if (!navMenu.contains(e.target) && !menuToggle.contains(e.target)) {
          toggleMenu(false);
        }
      });

      // Close menu when a link inside is clicked
      navMenu.querySelectorAll('a').forEach(function (link) {
        link.addEventListener('click', function () {
          toggleMenu(false);
        });
      });

      // Close on Escape key
      document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && navMenu.classList.contains('active')) {
          toggleMenu(false);
        }
      });
    }

    // Highlight current page active link
    const currentPath = window.location.pathname.replace(/\/+$/, '') || '/';
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(function (link) {
      const href = (link.getAttribute('href') || '').replace(/\/+$/, '') || '/';
      if (href === currentPath || (href === '/' && (currentPath === '' || currentPath === '/index.html'))) {
        link.classList.add('active');
      }
    });

    // Fixed Header Lock & Elementor parent container cleanup
    const header = document.getElementById('header');
    if (header) {
      function lockHeaderPosition() {
        header.style.setProperty('position', 'fixed', 'important');
        header.style.setProperty('top', '0px', 'important');
        header.style.setProperty('left', '0px', 'important');
        header.style.setProperty('right', '0px', 'important');
        header.style.setProperty('width', '100%', 'important');
        header.style.setProperty('z-index', '99999', 'important');

        // Check if WordPress admin bar is present and offset top
        const wpAdminBar = document.getElementById('wpadminbar');
        if (wpAdminBar) {
          const barHeight = wpAdminBar.offsetHeight || 32;
          header.style.setProperty('top', barHeight + 'px', 'important');
        }
      }

      window.addEventListener('scroll', lockHeaderPosition, { passive: true });
      window.addEventListener('resize', lockHeaderPosition);
      document.addEventListener('DOMContentLoaded', lockHeaderPosition);
      lockHeaderPosition();
    }
  })();
</script>

<main>
<!-- Contact Hero Section -->
  <section class="section contact-hero" id="contact">
    <div class="container">
      <div class="contact-card" id="contact-card">
        <div class="badge-partner" style="margin-bottom: 1.25rem;">
          <span class="badge-dot"></span>
          BoloUp Go Support Center
        </div>
        <h1 class="contact-card-title">Contact BoloUp Go – Support &amp; Help</h1>
        <p class="contact-card-desc">
          Contact BoloUp Go for help with your account, Host or Agent registration, withdrawals, agency questions, and other platform support.
        </p>

        <div class="contact-grid">
          <div class="contact-item" id="support-registration">
            <div class="contact-item-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="22" height="22" aria-hidden="true">
                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <line x1="19" y1="8" x2="19" y2="14" />
                <line x1="22" y1="11" x2="16" y2="11" />
              </svg>
            </div>
            <div class="contact-item-content">
              <h3>Host &amp; Agent Registration</h3>
              <p>Questions about joining an agency, ID 2527626 verification, or approval status.</p>
            </div>
          </div>

          <div class="contact-item" id="support-withdrawals">
            <div class="contact-item-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="22" height="22" aria-hidden="true">
                <rect x="2" y="4" width="20" height="16" rx="2" />
                <line x1="2" y1="10" x2="22" y2="10" />
              </svg>
            </div>
            <div class="contact-item-content">
              <h3>Withdrawals &amp; Earnings</h3>
              <p>Assistance with diamond payouts, payout methods (bank, e-wallet, USDT), and payout schedules.</p>
            </div>
          </div>

          <div class="contact-item" id="support-agency">
            <div class="contact-item-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="22" height="22" aria-hidden="true">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
            </div>
            <div class="contact-item-content">
              <h3>Agency Management</h3>
              <p>Support for Agents recruiting creators, managing host teams, and invitation links.</p>
            </div>
          </div>

          <div class="contact-item" id="support-platform">
            <div class="contact-item-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="22" height="22" aria-hidden="true">
                <circle cx="12" cy="12" r="10" />
                <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                <line x1="12" y1="17" x2="12.01" y2="17" />
              </svg>
            </div>
            <div class="contact-item-content">
              <h3>Platform &amp; Account Help</h3>
              <p>General inquiries, app downloads, authentication troubleshooting, and community policies.</p>
            </div>
          </div>
        </div>

        <div class="hero-actions" style="margin-top: 2.5rem; justify-content: center;">
          <a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer"
            class="btn btn-primary btn-lg" id="btn-contact-app">
            Download BoloUp Go App
          </a>
          <a href="/" class="btn btn-outline btn-lg" id="btn-contact-home">
            Back to Home
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- Internal JavaScript (Per Project Rules) -->
  <script>
    (function () {
      // Contact page initialization
    })();
  </script>
</main>
<!-- ==========================================================================
     BoloUp Go Official - Footer Component (footer.html)
     For WordPress Elementor Theme Builder Footer Template
     ========================================================================== -->
<footer class="footer" id="footer">
  <div class="container">
    <div class="footer-grid">
      <!-- Brand Overview -->
      <div class="footer-brand">
        <a href="/" class="brand-logo" id="footer-brand-logo" aria-label="BoloUp Go Home">
          <img src="https://boloupgo.app/wp-content/uploads/2026/11/logo-samping.png" alt="BoloUp Go Official Logo" class="brand-logo-icon" width="914" height="261" loading="lazy">
        </a>
        <p class="footer-desc">
          BoloUp Go is a social space for real-time connection. Bringing live video, voice rooms, conversations, creators, and income together in one place, whether you want to host or build a team behind the scenes.
        </p>
      </div>

      <!-- Navigation Links -->
      <div class="footer-col">
        <h3>Navigation</h3>
        <ul class="footer-links">
          <li><a href="/">Home</a></li>
          <li><a href="/host">Host</a></li>
          <li><a href="/agent">Agent</a></li>
          <li><a href="/contact">Contact</a></li>
        </ul>
      </div>

      <!-- Quick Resources -->
      <div class="footer-col">
        <h3>Host &amp; Agent</h3>
        <ul class="footer-links">
          <li><a href="/host">Become a Host</a></li>
          <li><a href="/host#registration">Host Registration</a></li>
          <li><a href="/agent">Become an Agent</a></li>
          <li><a href="/agent#registration">Agent Registration</a></li>
        </ul>
      </div>

      <!-- Platform Links -->
      <div class="footer-col">
        <h3>BoloUp Go</h3>
        <ul class="footer-links">
          <li><a href="https://share.bololinks.com/home/scode/47282" target="_blank" rel="noopener noreferrer">Download BoloUp Go</a></li>
          <li><a href="/contact">Contact &amp; Support</a></li>
        </ul>
      </div>
    </div>

    <!-- Bottom Bar -->
    <div class="footer-bottom">
      <div>&copy; 2026 BoloUp Go (boloupgo.app). All rights reserved.</div>
      <div>Live, Connect, Discover, and Earn More</div>
    </div>
  </div>
</footer>

<?php
get_footer();
